export default function AndroidMedium() {
  return <div className="bg-white size-full" data-name="Android Medium - 1" />;
}